# DuelPlugin

A 1v1 duel system for Spigot/Bukkit servers — duel requests, config-defined kits,
registered arenas, and win/loss stats. Built for Java 17 / Spigot 1.20.1.

This is an original implementation of the classic "kit PvP duel" feature set
(as popularized by servers like MCPVP) — request → accept → auto-teleport to a
free arena → fight with a fixed kit → loser is restored to their pre-duel state
and the fight ends before an actual death occurs.

## Features

- `/duel <player> <kit>` — challenge another online player to a duel with a specific kit
- Accept/deny/cancel flow with a 30-second request timeout (configurable)
- Automatic arena selection from a pool of admin-registered arenas
- Config-defined kits, saved directly from an admin's inventory
- Players are fully restored (inventory, armor, location, health, hunger,
  potion effects, game mode) after a duel ends
- Death is intercepted — the losing blow is cancelled and the loser is pulled
  out of the fight instead of actually dying
- Forfeit-on-disconnect, with inventory automatically restored on next rejoin
- Simple per-player win/loss counters (`/duel stats [player]`)
- Arena boundary enforcement so players can't wander out mid-fight

## Commands

| Command | Permission | Description |
|---|---|---|
| `/duel <player> <kit>` | `duel.use` | Send a duel request |
| `/duel accept` | `duel.use` | Accept the pending request |
| `/duel deny` | `duel.use` | Decline the pending request |
| `/duel cancel` | `duel.use` | Cancel your current duel (no stats recorded) |
| `/duel stats [player]` | `duel.use` | View win/loss record |
| `/duelarena create <name>` | `duel.admin` | Register a new arena |
| `/duelarena pos1 \| pos2 <name>` | `duel.admin` | Set arena boundary corners at your location |
| `/duelarena spawn1 \| spawn2 <name>` | `duel.admin` | Set each duelist's spawn point |
| `/duelarena remove <name>` | `duel.admin` | Delete an arena |
| `/duelarena list` | `duel.admin` | List all arenas and their status |
| `/duelkit create <name>` | `duel.admin` | Save your current inventory + armor as a kit |
| `/duelkit delete <name>` | `duel.admin` | Delete a kit |
| `/duelkit give <name>` | `duel.admin` | Give yourself a kit (for testing) |
| `/duelkit list` | `duel.admin` | List all kits |

## Setting up an arena

```
/duelarena create arena1
# stand at one corner of the fighting space
/duelarena pos1 arena1
# stand at the opposite corner
/duelarena pos2 arena1
# stand where player 1 should spawn
/duelarena spawn1 arena1
# stand where player 2 should spawn
/duelarena spawn2 arena1
```

An arena only enters the free-arena pool once all four points are set
(`/duelarena list` shows "ready" vs "incomplete").

## Setting up a kit

Build the exact inventory + armor you want players to duel with, then run:

```
/duelkit create archer
```

Kits are stored in `plugins/DuelPlugin/kits.yml`.

## Building

```
mvn clean package
```

The compiled jar is written to `target/DuelPlugin.jar`. A GitHub Actions
workflow (`.github/workflows/build.yml`) builds the plugin on every push and
pull request to `main`, and uploads the jar as a build artifact.

## Data files (in `plugins/DuelPlugin/`)

- `config.yml` — request timeout setting
- `arenas.yml` — registered arenas
- `kits.yml` — saved kits
- `stats.yml` — per-player win/loss counters

## Notes / possible extensions

- Currently one fixed kit per duel, chosen at request time — could be extended
  with a GUI kit picker.
- Stats are plain win/loss counters — swap in an ELO formula in `StatsManager`
  if you want ranked ladders later.
- Arena selection is "first free arena" — could be extended to let players
  pick a specific arena by name.
